#ifndef __BSP_GPS_USARTX_H__
#define	__BSP_GPS_USARTX_H__

/* ����ͷ�ļ� ----------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>

/* ���Ͷ��� ------------------------------------------------------------------*/
/* �궨�� --------------------------------------------------------------------*/
#define GPS_USARTx_BAUDRATE                        9600

#define GPS_USARTx                                 USART2
#define GPS_USARTx_ClockCmd                        RCC_APB1PeriphClockCmd
#define GPS_USARTx_CLK                             RCC_APB1Periph_USART2

#define GPS_USARTx_GPIO_ClockCmd                   RCC_APB2PeriphClockCmd    
#define GPS_USARTx_TX_PORT                         GPIOA   
#define GPS_USARTx_TX_PIN                          GPIO_Pin_2
#define GPS_USARTx_TX_CLK                          RCC_APB2Periph_GPIOA 
#define GPS_USARTx_RX_PORT                         GPIOA 
#define GPS_USARTx_RX_PIN                          GPIO_Pin_3
#define GPS_USARTx_RX_CLK                          RCC_APB2Periph_GPIOA

/* ��չ���� ------------------------------------------------------------------*/
/* �������� ------------------------------------------------------------------*/
void GPS_USARTx_Config(void);

#endif /* __BSP_GPS_USARTX_H__ */

/******************* (C) COPYRIGHT 2015-2020 ӲʯǶ��ʽ�����Ŷ� *****END OF FILE****/
