#include "reg51.h"
#include "ili9341.h"

#define     RED          0XF800	  //��ɫ
#define     GREEN        0X07E0	  //��ɫ
#define     BLUE         0X001F	  //��ɫ
#define     WHITE        0XFFFF	  //��ɫ

/* Ӳ������ */
// P3^2---LCD_CS
// P3^6---LCD_RESET
// P1^5---LCD_MOSI
// P1^6---LCD_MISO
// P1^7---LCD_SCK (LCD_RS)

void main(void)
{
	delay_ms(100);
	LCD_Init();
	
	while(1)
	{
		LCD_Clear(WHITE);
		delay_ms(300);
		LCD_Clear(RED);
		delay_ms(300);
		LCD_Clear(BLUE);
		delay_ms(300);
		LCD_Clear(GREEN);
		delay_ms(300);
	}
}

























