#ifndef __ILI9341_H
#define __ILI9341_H

#include "reg51.h"

sbit LCD_CS = P3^2;
sbit LCD_RESET = P3^6;
sbit LCD_MOSI = P1^5;
sbit LCD_MISO = P1^6;
sbit LCD_SCK = P1^7;//����TFT�ϵ�LCD_RS����

void delay_ms(unsigned int ms);
void LCD_Init(void);
void LCD_SetArea(unsigned int stx,unsigned int sty,unsigned int endx,unsigned int endy);
void LcdWirteColorData(unsigned int color);
void LCD_Clear(unsigned int color);
	
#endif 
