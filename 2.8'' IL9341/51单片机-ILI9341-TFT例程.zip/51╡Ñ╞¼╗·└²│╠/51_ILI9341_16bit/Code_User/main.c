#include "reg51.h"
#include "ili9341.h"

#define     RED          0XF800	  //��ɫ
#define     GREEN        0X07E0	  //��ɫ
#define     BLUE         0X001F	  //��ɫ
#define     WHITE        0XFFFF	  //��ɫ

/* Ӳ������ */
// P0^0---DB0
// P0^1---DB1
// P0^2---DB2
// P0^3---DB3
// P0^4---DB4
// P0^5---DB5
// P0^6---DB6
// P0^7---DB7
// P2^0---DB8
// P2^1---DB9
// P2^2---DB10
// P2^3---DB11
// P2^4---DB12
// P2^5---DB13
// P2^6---DB14
// P2^7---DB15
// P3^2---LCD_CS
// P3^3---LCD_RS
// P3^4---LCD_WR
// P3^5---LCD_RD
// P3^6---LCD_RESET

void main(void)
{
	delay_ms(100);
	LCD_Init();
	
	while(1)
	{
		LCD_Clear(WHITE);
		delay_ms(300);
		LCD_Clear(RED);
		delay_ms(300);
		LCD_Clear(BLUE);
		delay_ms(300);
		LCD_Clear(GREEN);
		delay_ms(300);
	}
}

























