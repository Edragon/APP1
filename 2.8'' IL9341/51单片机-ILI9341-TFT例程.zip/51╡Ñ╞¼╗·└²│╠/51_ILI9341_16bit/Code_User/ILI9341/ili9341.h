#ifndef __ILI9341_H
#define __ILI9341_H

#include "reg51.h"

sbit LCD_CS = P3^2;
sbit LCD_RS = P3^3;
sbit LCD_WR = P3^4;
sbit LCD_RD = P3^5;
sbit LCD_RESET = P3^6;

void delay_ms(unsigned int ms);
void LCD_Init(void);
void LCD_SetArea(unsigned int stx,unsigned int sty,unsigned int endx,unsigned int endy);
void LcdWirteColorData(unsigned int color);
void LCD_Clear(unsigned int color);
	
#endif 
