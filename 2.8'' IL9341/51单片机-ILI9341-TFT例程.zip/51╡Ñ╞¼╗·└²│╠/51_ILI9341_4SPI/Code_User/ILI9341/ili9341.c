#include "ili9341.h"

void Delay1ms()		//@12.000MHz
{
	unsigned char i, j;

	i = 12;
	j = 169;
	do
	{
		while (--j);
	} while (--i);
}

void delay_ms(unsigned int ms)
{
	while(ms--)
	{
		Delay1ms();
	}
}

unsigned char SPI_RW(unsigned char byte)
{
	unsigned char bit_ctr;
	
	for(bit_ctr=0;bit_ctr<8;bit_ctr++) // ���8λ
	{
		LCD_SCK=0;
		LCD_MOSI=(byte&0x80); // MSB TO MOSI
		byte=(byte<<1);	// shift next bit to MSB
		LCD_SCK=1;
		byte|=LCD_MISO;	        // capture current MISO bit
	}
	return byte;
}

void LCD_CD_DATA(unsigned char val)
{
	LCD_CS=0;
	LCD_CD=1;
	SPI_RW(val);
	LCD_CS=1;
}

void LCD_CD_REG(unsigned char reg)
{
	LCD_CS=0;
	LCD_CD=0;
	SPI_RW(reg);
	LCD_CS=1;
}

void LCD_Init()
{
	P0=0;
	P2=0;
	LCD_RESET=0;
	delay_ms(10);
	LCD_RESET=1;
	delay_ms(120);
	LCD_CD_REG(0xCF);  
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0xC1); 
	LCD_CD_DATA(0X30); 
	LCD_CD_REG(0xED);  
	LCD_CD_DATA(0x64); 
	LCD_CD_DATA(0x03); 
	LCD_CD_DATA(0X12); 
	LCD_CD_DATA(0X81); 
	LCD_CD_REG(0xE8);  
	LCD_CD_DATA(0x85); 
	LCD_CD_DATA(0x10); 
	LCD_CD_DATA(0x7A); 
	LCD_CD_REG(0xCB);  
	LCD_CD_DATA(0x39); 
	LCD_CD_DATA(0x2C); 
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x34); 
	LCD_CD_DATA(0x02); 
	LCD_CD_REG(0xF7);  
	LCD_CD_DATA(0x20); 
	LCD_CD_REG(0xEA);  
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x00); 
	LCD_CD_REG(0xC0);    //Power control 
	LCD_CD_DATA(0x1B);   //VRH[5:0] 
	LCD_CD_REG(0xC1);    //Power control 
	LCD_CD_DATA(0x01);   //SAP[2:0];BT[3:0] 
	LCD_CD_REG(0xC5);    //VCM control 
	LCD_CD_DATA(0x30); 	 //3F
	LCD_CD_DATA(0x30); 	 //3C
	LCD_CD_REG(0xC7);    //VCM control2 
	LCD_CD_DATA(0XB7); 
	LCD_CD_REG(0x36);    // Memory Access Control 
	LCD_CD_DATA(0x48); 
	LCD_CD_REG(0x3A);   
	LCD_CD_DATA(0x55); 
	LCD_CD_REG(0xB1);   
	LCD_CD_DATA(0x00);   
	LCD_CD_DATA(0x1A); 
	LCD_CD_REG(0xB6);    // Display Function Control 
	LCD_CD_DATA(0x0A); 
	LCD_CD_DATA(0xA2); 
	LCD_CD_REG(0xF2);    // 3Gamma Function Disable 
	LCD_CD_DATA(0x00); 
	LCD_CD_REG(0x26);    //Gamma curve selected 
	LCD_CD_DATA(0x01); 
	LCD_CD_REG(0xE0);    //Set Gamma 
	LCD_CD_DATA(0x0F); 
	LCD_CD_DATA(0x2A); 
	LCD_CD_DATA(0x28); 
	LCD_CD_DATA(0x08); 
	LCD_CD_DATA(0x0E); 
	LCD_CD_DATA(0x08); 
	LCD_CD_DATA(0x54); 
	LCD_CD_DATA(0XA9); 
	LCD_CD_DATA(0x43); 
	LCD_CD_DATA(0x0A); 
	LCD_CD_DATA(0x0F); 
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x00); 		 
	LCD_CD_REG(0XE1);    //Set Gamma 
	LCD_CD_DATA(0x00); 
	LCD_CD_DATA(0x15); 
	LCD_CD_DATA(0x17); 
	LCD_CD_DATA(0x07); 
	LCD_CD_DATA(0x11); 
	LCD_CD_DATA(0x06); 
	LCD_CD_DATA(0x2B); 
	LCD_CD_DATA(0x56); 
	LCD_CD_DATA(0x3C); 
	LCD_CD_DATA(0x05); 
	LCD_CD_DATA(0x10); 
	LCD_CD_DATA(0x0F); 
	LCD_CD_DATA(0x3F); 
	LCD_CD_DATA(0x3F); 
	LCD_CD_DATA(0x0F); 
	LCD_CD_REG(0x2B); 
	LCD_CD_DATA(0x00);
	LCD_CD_DATA(0x00);
	LCD_CD_DATA(0x01);
	LCD_CD_DATA(0x3f);
	LCD_CD_REG(0x2A); 
	LCD_CD_DATA(0x00);
	LCD_CD_DATA(0x00);
	LCD_CD_DATA(0x00);
	LCD_CD_DATA(0xef);	 
	LCD_CD_REG(0x11); //Exit Sleep
	delay_ms(120);
	LCD_CD_REG(0x29); //display on	
}

void LCD_SetArea(unsigned int stx,unsigned int sty,unsigned int endx,unsigned int endy)
{
	LCD_CD_REG(0x2A);  
	LCD_CD_DATA(stx>>8);    
	LCD_CD_DATA(stx&0xff);    	
	LCD_CD_DATA(endx>>8); 
	LCD_CD_DATA(endx&0xff);	

	LCD_CD_REG(0x2B);
	LCD_CD_DATA(sty>>8); 
	LCD_CD_DATA(sty&0xff);	
	LCD_CD_DATA(endy>>8); 
	LCD_CD_DATA(endy&0xff);	
}

void LcdWirteColorData(unsigned int color)
{
	LCD_CS=0;
	LCD_CD=1;
	SPI_RW(color>>8);
	SPI_RW(color);
	LCD_CS=1;
}

void LCD_Clear(unsigned int color)
{  
	unsigned int i,j;

	LCD_SetArea(0,0,239,319);
  LCD_CD_REG(0x2C);
	for(i=0;i<320;i++)
	{
		for(j=0;j<240;j++)
		{
			LcdWirteColorData(color);
		}
	}
}
