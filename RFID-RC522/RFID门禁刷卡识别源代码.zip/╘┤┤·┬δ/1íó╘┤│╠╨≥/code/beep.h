#ifndef _BEEP_H_
#define _BEEP_H_

extern void  beep1();
extern void  LED_BLINK_1();
extern void  LED_BLINK_2();
extern void relay_OFF();  //�ؼ̵���
extern void relay_ON();  //�ؼ̵���
extern void relay_Change();

#endif
