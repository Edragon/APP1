#ifndef _EEPROM_H_
#define _EEPROM_H_	 

extern void   EEPROM_READ(INT8U a, INT8U *p,INT8U b);
extern void   EEPROM_WRITE(INT8U a,INT8U *p,INT8U b); 

#endif
