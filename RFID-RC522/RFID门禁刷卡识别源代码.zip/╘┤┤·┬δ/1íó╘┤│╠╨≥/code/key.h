#ifndef _KEY_H_
#define _KEY_H_	 

extern unsigned char key_scan(void);

#endif
